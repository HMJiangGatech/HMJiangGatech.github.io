The data was downloaded from https://github.com/facebookresearch/ParlAI/tree/master/projects/controllable_dialogue.
We also use the pre-trained model from the same github repo.
The hyperparameters of these agents is listed in `model_configs.py`.
The `stats.csv` summarize the human evaluation performance for each agent.
The code for generating the data is similar to 
https://github.com/facebookresearch/ParlAI/issues/2855.

File structure: 

`opedata`: use all human-agent evaluation logs
`opedata_hard`: subsampled by 50%
`opedata_small`: subsampled by 10%
`opedata_hard`: Filter out very similar experence data for each agent

There are 28 subfolder containing pre-processed opedata for the 28 target agents. The data.json file can be directed used by ENIGMA: https://github.com/google-research/google-research/tree/master/dialogue_ope/airdialogue_ope.

The json fileds of data.json:
`dialog`: e1,a1,a1',e2,a2,a2',....,   (ei: human, ai: behavior agent, ai': target agent)
`reward`: 10 human evaluation score for behavior dialogue (e0,a0,e1,a1,....)
'model_persona', 'human_persona': the persona of the agents


Reference
Abigail See, Stephen Roller, Douwe Kiela, Jason Weston. What makes a good conversation? How controllable attributes affect human judgments. To appear in NAACL 2019.